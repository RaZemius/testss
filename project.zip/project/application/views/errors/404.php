<?php
echo "ERROR 404";