<?php
return [

	'' => [
		'controller' => 'main',
		'action' => 'index'
	],
];
