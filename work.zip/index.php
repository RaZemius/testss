
<?php
require 'app/lib/Autoloader.php';

use app\lib\Debug; //Не забудьте добавить namespace в файл с классом Debug!
use app\core\Router;
Autoloader::register(); //Запускаем автозагрузчик

session_start(); //Начинаем сессию
$debug = new Debug();
$router = new Router();
$router->run();
