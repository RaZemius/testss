<?php

class text{
public static function print($data) {
echo '<pre>';
	var_dump($data);
	echo '</pre>';
}}