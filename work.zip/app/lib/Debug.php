<?php
namespace app\lib;
// Пример каркаса класса
class Debug {
	function __construct() {
        //При создании экземпляра класса Debug, будет сразу же включаться отображение ошибок

        ini_set('display_errors', 1);
        error_reporting(E_ALL);
    }

	function __destruct() {

        ini_set('display_errors', 1);
        error_reporting(E_ALL);
		//При уничтожении экземпляра класса, отображение ошибок отключится
	}
    public static function print($data)
    {
        echo '<pre>';
        var_dump($data);
        echo '</pre>';
    }
}