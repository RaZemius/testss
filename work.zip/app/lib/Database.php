<?php
namespace app\lib;
use PDO;

class Database {

protected $database;

public function __construct() {
// Создание в переменной $database нового объекта PDO с параметрами из файла dbconfig
    $c  = require 'app/config/dbconfig.php';
    $options = require 'app/config/pdoconfig.php';
    $dns = "mysql:host=$c->host;dbname=$c->database;charset=UTF-8";
    $this->database = new PDO($dns, $c->username,$c->pass, $options);
}

public function query($sql, $params = []) {
    $stmt = $this->database->prepare($sql);
    if (!empty($params)) {
        foreach ($params as $key => $val) {
            if (is_int($val)) {
                $type = PDO::PARAM_INT;
            } else {
                $type = PDO::PARAM_STR;
            }
            $stmt->bindValue(':'.$key, $val, $type);
        }
    }
    $stmt->execute();
    return $stmt;
}

public function row($sql, $params = []) {
        //Вызов функции $this->query с аргументом $params и возврат результата с помощью fetchAll(PDO::FETCH_ASSOC)
    $g=$this->query($sql, $params);
    return $g->fetch(PDO::FETCH_ASSOC);
}

public function column($sql, $params = []) {
        //Вызов функции $this->query с аргументом $params и возврат результата с помощью fetchСolumn()
       $g= $this->query($sql, $params);
        return $g->fetchColumn();
}


public function lastInsertId() {
//ГОТОВО: Возврат идентификатора последней строки, вставленной в таблицу БД
return $this->database->lastInsertId();
}

}
