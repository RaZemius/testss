<?php
namespace app\controllers;
use app\core\Controller;
class AccountController extends Controller{
    public function enterAction(){
        print('<p></p><a href= "https://localhost/webalizer/">RETURN</a>');
        print('<p></p><a href= "https://localhost/webalizer/account/login">login</a>');
        print('<p></p><a href= "https://localhost/webalizer/account/reg">regestration</a>');
    }
    public function logAction(){
        
        echo 'trig log';
    }
    public function regAction(){
        echo 'trig reg';
    }
}


?>