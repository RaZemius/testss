<?php
namespace app\controllers;
use app\core\Controller;
class MainController extends Controller{
    public function indexAction(){
        print('<p></p><a href= "https://localhost/webalizer/account/enter">account</a>');

        print('<p></p><a href= "https://localhost/webalizer/ffff.php">проектирование</a>');
    }
}