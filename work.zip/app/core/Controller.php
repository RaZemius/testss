<?php
namespace app\core;

use app\core\View;
abstract class Controller{
    public $route;
    public function __construct($params)
    {
        $this->route = $params;
        $view = new View($this->route);
    }
    public function loadModel($name)
    {
        $path = 'app\models\\' . ucfirst($name);
        if (class_exists($path)) {
            return new $path;
        }
    }
}