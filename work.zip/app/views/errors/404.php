<!DOCTYPE html>
<style>
    @import url("https://fonts.googleapis.com/css?family=Roboto+Mono:300,500");

    html,
    body {
        width: 100%;
        height: 100%;
    }

    body {
        background-image: url(https://localhost/webalizer/spaaace.jpg) ;
        background-size: cover;
        background-repeat: no-repeat;
        min-height: 100vh;
        min-width: 100vw;
        font-family: "Roboto Mono", "Liberation Mono", Consolas, monospace;
        color: rgba(255, 255, 255, 0.87);
    }

    .mx-auto {
        margin-left: auto;
        margin-right: auto;
    }

    .container,
    .container>.row,
    .container>.row>div {
        height: 100%;
    }

    #countUp {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: 100%;
    }

    #countUp .number {
        font-size: 4rem;
        font-weight: 500;
    }

    #countUp .number+.text {
        margin: 0 0 1rem;
    }

    #countUp .text {
        font-weight: 300;
        text-align: center;
    }
</style>
<div class="container">
    <div class="row">
        <div class="xs-12 md-6 mx-auto">
            <div id="countUp">
                <div class="number" data-count="404">404</div>
                <div class="text">Page not found</div>
                <div class="text">This may not mean anything.</div>
                <div class="text">I'm probably working on something that has blown up.</div>
            </div>
        </div>
    </div>
</div>