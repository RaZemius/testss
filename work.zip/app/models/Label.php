<?php

use app\core\Model;

class lable extends Model{
    
    public function __construct()
    {
        
    }
    public function AllTable(){
        $sql = 'from lable';
        return $this->db->query($sql);
    }
}