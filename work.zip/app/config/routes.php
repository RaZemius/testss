<?php
return [
	'webalizer' => [
		'controller' => 'main',
		'action' => 'index'
	],
	'webalizer/account/enter' => [
		'controller' => 'account',
		'action' => 'enter',
	],

	'posts/show' => [
		'controller' => 'posts',
		'action' => 'show',
	],

	'webalizer/account/login' => [
		'controller' => 'account',
		'action' => 'log',
	],

	'webalizer/account/reg' => [
		'controller' => 'account',
		'action' => 'reg',
	],
    ];