<?php
return (object) array(
'host' => 'localhost',
'username' => 'core',
'pass' => 'hash',
'database' => 'gs'
);